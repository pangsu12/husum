import { useState } from "react";
import { ArrowLeft, CheckCircle, Send } from "lucide-react";

interface ReportScreenProps {
  onBack: () => void;
}

type OptionPair = {
  label: string;
  options: [string, string];
  key: string;
};

const reportItems: OptionPair[] = [
  { key: "open", label: "운영 상태", options: ["운영 중", "문 닫힘"] },
  { key: "cooling", label: "냉방 상태", options: ["냉방 잘 됨", "냉방 약함"] },
  { key: "heating", label: "난방 상태", options: ["난방 잘 됨", "난방 약함"] },
  { key: "crowd", label: "혼잡도", options: ["혼잡함", "여유 있음"] },
  { key: "water", label: "물 제공", options: ["물 제공", "미제공"] },
  { key: "wheelchair", label: "휠체어 접근", options: ["접근 가능", "불가능"] },
  { key: "danger", label: "위험 경로", options: ["위험 경로 없음", "위험 경로 있음"] },
];

export function ReportScreen({ onBack }: ReportScreenProps) {
  const [selections, setSelections] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);

  const select = (key: string, value: string) => {
    setSelections((prev) => ({ ...prev, [key]: value }));
  };

  const handleSubmit = () => {
    setSubmitted(true);
  };

  const filled = Object.keys(selections).length;

  if (submitted) {
    return (
      <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", background: "#F4F7FB", padding: 32 }}>
        <div style={{ fontSize: 64, marginBottom: 20 }}>🎉</div>
        <div style={{ fontSize: 22, fontWeight: 800, color: "#111827", marginBottom: 10, textAlign: "center" }}>
          제보해 주셔서 감사합니다!
        </div>
        <div style={{ fontSize: 14, color: "#6B7280", textAlign: "center", lineHeight: 1.6, marginBottom: 32 }}>
          소중한 제보가 다른 이용자의<br />쉼터 추천 정확도를 높이는 데<br />도움이 됩니다.
        </div>
        <div
          style={{
            background: "#ECFDF5",
            borderRadius: 14,
            padding: "14px 20px",
            marginBottom: 24,
            display: "flex",
            alignItems: "center",
            gap: 8,
          }}
        >
          <CheckCircle size={18} color="#059669" />
          <span style={{ fontSize: 14, fontWeight: 600, color: "#059669" }}>제보가 등록되었습니다</span>
        </div>
        <button
          onClick={onBack}
          style={{ background: "#1D6FE8", color: "#fff", border: "none", borderRadius: 14, padding: "14px 40px", fontSize: 15, fontWeight: 700, cursor: "pointer" }}
        >
          돌아가기
        </button>
      </div>
    );
  }

  return (
    <div style={{ flex: 1, overflowY: "auto", background: "#F4F7FB" }}>
      {/* Header */}
      <div
        style={{
          background: "linear-gradient(135deg, #F97316 0%, #EF4444 100%)",
          paddingTop: 52,
          paddingLeft: 16,
          paddingRight: 16,
          paddingBottom: 24,
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
          <button onClick={onBack} style={{ border: "none", background: "rgba(255,255,255,0.2)", borderRadius: 10, padding: 8, cursor: "pointer" }}>
            <ArrowLeft size={18} color="#fff" />
          </button>
          <div>
            <div style={{ color: "rgba(255,255,255,0.75)", fontSize: 12 }}>시민 제보</div>
            <div style={{ color: "#fff", fontSize: 18, fontWeight: 700 }}>쉼터 상태 알려주세요</div>
          </div>
        </div>
        <div
          style={{
            background: "rgba(255,255,255,0.15)",
            borderRadius: 12,
            padding: "10px 14px",
            fontSize: 13,
            color: "rgba(255,255,255,0.9)",
            lineHeight: 1.5,
          }}
        >
          📢 쉼터 상태를 알려주시면 다른 사용자의 추천 정확도를 높이는 데 도움이 됩니다
        </div>
      </div>

      <div style={{ padding: "16px 16px 100px", display: "flex", flexDirection: "column", gap: 10 }}>
        {/* Shelter name */}
        <div style={{ background: "#fff", borderRadius: 16, padding: "14px 16px", boxShadow: "0 1px 6px rgba(0,0,0,0.05)", display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ fontSize: 20 }}>🏢</span>
          <div>
            <div style={{ fontSize: 13, fontWeight: 700, color: "#111827" }}>성북종합사회복지관</div>
            <div style={{ fontSize: 12, color: "#9CA3AF" }}>서울 성북구 동소문로 47</div>
          </div>
        </div>

        {reportItems.map((item) => (
          <div key={item.key} style={{ background: "#fff", borderRadius: 16, padding: "14px 14px", boxShadow: "0 1px 6px rgba(0,0,0,0.05)" }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: "#374151", marginBottom: 10 }}>
              {item.label}
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              {item.options.map((opt) => {
                const active = selections[item.key] === opt;
                const isPositive = item.options.indexOf(opt) === 0;
                return (
                  <button
                    key={opt}
                    onClick={() => select(item.key, opt)}
                    style={{
                      flex: 1,
                      border: active ? `2px solid ${isPositive ? "#059669" : "#EF4444"}` : "2px solid #E5E7EB",
                      borderRadius: 12,
                      padding: "11px 8px",
                      fontSize: 13,
                      fontWeight: active ? 700 : 400,
                      cursor: "pointer",
                      background: active ? (isPositive ? "#ECFDF5" : "#FEF2F2") : "#F8FAFC",
                      color: active ? (isPositive ? "#059669" : "#EF4444") : "#374151",
                      transition: "all 0.15s",
                    }}
                  >
                    {active && (isPositive ? "✓ " : "! ")}{opt}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Submit button (fixed) */}
      <div
        style={{
          position: "sticky",
          bottom: 0,
          padding: "12px 16px 24px",
          background: "linear-gradient(to top, #F4F7FB 70%, transparent)",
        }}
      >
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
          <span style={{ fontSize: 12, color: "#9CA3AF" }}>{filled} / {reportItems.length}개 선택됨</span>
          <div style={{ height: 4, width: 120, background: "#E5E7EB", borderRadius: 10, overflow: "hidden" }}>
            <div style={{ height: "100%", width: `${(filled / reportItems.length) * 100}%`, background: "#1D6FE8", borderRadius: 10, transition: "width 0.2s" }} />
          </div>
        </div>
        <button
          onClick={handleSubmit}
          disabled={filled === 0}
          style={{
            width: "100%",
            background: filled > 0 ? "#1D6FE8" : "#E5E7EB",
            color: filled > 0 ? "#fff" : "#9CA3AF",
            border: "none",
            borderRadius: 16,
            padding: "16px 0",
            fontSize: 15,
            fontWeight: 700,
            cursor: filled > 0 ? "pointer" : "default",
            transition: "background 0.2s",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
          }}
        >
          <Send size={17} />
          제보 제출
        </button>
      </div>
    </div>
  );
}
