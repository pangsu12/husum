import { ChevronRight, Bell, Info, Settings, Star, User } from "lucide-react";

interface MyScreenProps {
  onNavigate: (screen: string) => void;
}

export function MyScreen({ onNavigate }: MyScreenProps) {
  const conditions = ["어르신", "대중교통 이용"];

  return (
    <div style={{ flex: 1, overflowY: "auto", background: "#F4F7FB" }}>
      {/* Header */}
      <div
        style={{
          background: "linear-gradient(135deg, #1D6FE8 0%, #1558C0 100%)",
          paddingTop: 52,
          paddingBottom: 32,
          paddingLeft: 20,
          paddingRight: 20,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <div
          style={{
            width: 64,
            height: 64,
            background: "rgba(255,255,255,0.2)",
            borderRadius: "50%",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            marginBottom: 10,
          }}
        >
          <User size={32} color="#fff" />
        </div>
        <div style={{ color: "#fff", fontSize: 18, fontWeight: 700 }}>게스트 사용자</div>
        <div style={{ color: "rgba(255,255,255,0.7)", fontSize: 12, marginTop: 4 }}>
          로그인하면 더 정확한 추천을 받을 수 있어요
        </div>
      </div>

      <div style={{ padding: "16px 16px 40px", display: "flex", flexDirection: "column", gap: 12 }}>

        {/* Current conditions */}
        <div style={{ background: "#fff", borderRadius: 18, padding: "16px", boxShadow: "0 1px 8px rgba(0,0,0,0.05)" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
            <div style={{ fontSize: 14, fontWeight: 700, color: "#111827" }}>현재 맞춤 조건</div>
            <button
              onClick={() => onNavigate("settings")}
              style={{ background: "none", border: "none", color: "#1D6FE8", fontSize: 12, fontWeight: 600, cursor: "pointer" }}
            >
              수정
            </button>
          </div>
          <div
            style={{
              background: "#EFF4FF",
              borderRadius: 12,
              padding: "10px 12px",
              fontSize: 12,
              color: "#6B7280",
              marginBottom: 10,
            }}
          >
            ⚙️ 선택한 조건은 쉼터 추천 점수에 반영됩니다
          </div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
            {conditions.map((c) => (
              <span
                key={c}
                style={{
                  background: "#EFF4FF",
                  color: "#1D6FE8",
                  borderRadius: 20,
                  padding: "5px 12px",
                  fontSize: 13,
                  fontWeight: 500,
                }}
              >
                {c}
              </span>
            ))}
            <button
              onClick={() => onNavigate("settings")}
              style={{
                background: "#F3F4F6",
                color: "#6B7280",
                border: "1px dashed #D1D5DB",
                borderRadius: 20,
                padding: "5px 12px",
                fontSize: 13,
                cursor: "pointer",
              }}
            >
              + 추가
            </button>
          </div>
        </div>

        {/* Menu sections */}
        <MenuSection
          title="내 활동"
          items={[
            { icon: <Star size={17} color="#F59E0B" />, label: "즐겨찾기 쉼터", count: 3, action: () => onNavigate("favorites") },
          ]}
        />

        <MenuSection
          title="설정"
          items={[
            { icon: <Settings size={17} color="#6B7280" />, label: "맞춤 조건 설정", action: () => onNavigate("settings") },
            { icon: <Bell size={17} color="#6B7280" />, label: "알림 설정" },
          ]}
        />

        <MenuSection
          title="앱 정보"
          items={[
            { icon: <Info size={17} color="#6B7280" />, label: "앱 소개" },
            { icon: <Info size={17} color="#6B7280" />, label: "개인정보 처리방침" },
            { icon: <Info size={17} color="#6B7280" />, label: "버전 정보", sub: "v1.2.0" },
          ]}
        />

        {/* App description */}
        <div
          style={{
            background: "#EFF4FF",
            borderRadius: 18,
            padding: "16px 16px",
            border: "1px solid #BFDBFE",
          }}
        >
          <div style={{ fontSize: 14, fontWeight: 700, color: "#1D6FE8", marginBottom: 8 }}>
            🌡 휴숨이란?
          </div>
          <div style={{ fontSize: 13, color: "#374151", lineHeight: 1.7 }}>
            폭염·한파 상황에서 현재 위치 기준으로 가장 적합한 쉼터를 빠르게 찾아주는 공공 서비스입니다.
            기상 데이터, 시민 제보, 맞춤 조건을 종합해 온열질환 위험을 줄이는 것이 목표입니다.
          </div>
        </div>
      </div>
    </div>
  );
}

function MenuSection({
  title,
  items,
}: {
  title: string;
  items: Array<{ icon: React.ReactNode; label: string; count?: number; sub?: string; action?: () => void }>;
}) {
  return (
    <div style={{ background: "#fff", borderRadius: 18, overflow: "hidden", boxShadow: "0 1px 8px rgba(0,0,0,0.05)" }}>
      <div style={{ padding: "12px 16px 8px", fontSize: 12, color: "#9CA3AF", fontWeight: 600 }}>
        {title}
      </div>
      {items.map((item, i) => (
        <button
          key={item.label}
          onClick={item.action}
          style={{
            width: "100%",
            background: "none",
            border: "none",
            borderTop: i === 0 ? "none" : "1px solid #F3F4F6",
            padding: "14px 16px",
            display: "flex",
            alignItems: "center",
            gap: 12,
            cursor: item.action ? "pointer" : "default",
            textAlign: "left",
          }}
        >
          {item.icon}
          <span style={{ flex: 1, fontSize: 14, fontWeight: 500, color: "#111827" }}>{item.label}</span>
          {item.count !== undefined && (
            <span style={{ background: "#EFF4FF", color: "#1D6FE8", borderRadius: 20, padding: "2px 10px", fontSize: 12, fontWeight: 700 }}>
              {item.count}
            </span>
          )}
          {item.sub && (
            <span style={{ fontSize: 12, color: "#9CA3AF" }}>{item.sub}</span>
          )}
          {item.action && <ChevronRight size={16} color="#D1D5DB" />}
        </button>
      ))}
    </div>
  );
}
