import { ArrowLeft, Navigation, Star, Bell, CheckCircle, XCircle, Clock, MapPin, Phone, Wind, Droplets, Users, Accessibility, PawPrint } from "lucide-react";

interface ShelterDetailScreenProps {
  onBack: () => void;
}

export function ShelterDetailScreen({ onBack }: ShelterDetailScreenProps) {
  return (
    <div style={{ flex: 1, overflowY: "auto", background: "#F4F7FB" }}>
      {/* Top bar */}
      <div
        style={{
          background: "#fff",
          paddingTop: 52,
          paddingLeft: 16,
          paddingRight: 16,
          paddingBottom: 14,
          display: "flex",
          alignItems: "center",
          gap: 10,
          boxShadow: "0 1px 6px rgba(0,0,0,0.05)",
        }}
      >
        <button
          onClick={onBack}
          style={{ border: "none", background: "none", cursor: "pointer", padding: 4 }}
        >
          <ArrowLeft size={22} color="#374151" />
        </button>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 17, fontWeight: 700, color: "#111827" }}>
            성북종합사회복지관
          </div>
          <div style={{ fontSize: 12, color: "#6B7280" }}>서울 성북구 동소문로 47</div>
        </div>
        <button style={{ border: "none", background: "none", cursor: "pointer" }}>
          <Star size={22} color="#9CA3AF" />
        </button>
      </div>

      {/* Quick summary cards */}
      <div style={{ display: "flex", gap: 10, padding: "14px 16px 0", overflowX: "auto" }}>
        {[
          { icon: <CheckCircle size={18} color="#059669" />, label: "운영 중", sub: "09:00 ~ 18:00", color: "#ECFDF5" },
          { icon: <Clock size={18} color="#1D6FE8" />, label: "도보 3분", sub: "220m", color: "#EFF4FF" },
          { icon: <Wind size={18} color="#0369A1" />, label: "냉방 쾌적", sub: "25°C 유지", color: "#E0F2FE" },
          { icon: <Users size={18} color="#059669" />, label: "혼잡도 낮음", sub: "여유 있음", color: "#ECFDF5" },
        ].map((item) => (
          <div
            key={item.label}
            style={{
              background: item.color,
              borderRadius: 14,
              padding: "12px 14px",
              flexShrink: 0,
              textAlign: "center",
              minWidth: 80,
            }}
          >
            <div style={{ display: "flex", justifyContent: "center", marginBottom: 5 }}>{item.icon}</div>
            <div style={{ fontSize: 12, fontWeight: 600, color: "#111827" }}>{item.label}</div>
            <div style={{ fontSize: 11, color: "#6B7280", marginTop: 2 }}>{item.sub}</div>
          </div>
        ))}
      </div>

      <div style={{ padding: "14px 16px 32px", display: "flex", flexDirection: "column", gap: 12 }}>

        {/* Score */}
        <div style={{ background: "#fff", borderRadius: 18, padding: "16px", boxShadow: "0 1px 8px rgba(0,0,0,0.05)" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
            <span style={{ fontSize: 14, fontWeight: 600, color: "#374151" }}>추천 적합도</span>
            <span style={{ fontSize: 22, fontWeight: 800, color: "#1D6FE8" }}>92<span style={{ fontSize: 14 }}>/100</span></span>
          </div>
          <div style={{ height: 8, background: "#EFF4FF", borderRadius: 10, overflow: "hidden" }}>
            <div style={{ height: "100%", width: "92%", background: "linear-gradient(90deg, #1D6FE8, #60A5FA)", borderRadius: 10 }} />
          </div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginTop: 12 }}>
            {["가까움", "운영 중", "냉방 쾌적", "혼잡도 낮음", "물 제공", "휠체어 접근 가능"].map((t) => (
              <span key={t} style={{ background: "#EFF4FF", color: "#1D6FE8", borderRadius: 20, padding: "3px 10px", fontSize: 12, fontWeight: 500 }}>{t}</span>
            ))}
          </div>
        </div>

        {/* Basic info */}
        <div style={{ background: "#fff", borderRadius: 18, padding: "16px", boxShadow: "0 1px 8px rgba(0,0,0,0.05)" }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: "#111827", marginBottom: 12 }}>기본 정보</div>
          {[
            { icon: <MapPin size={15} color="#6B7280" />, label: "주소", value: "서울 성북구 동소문로 47길 10" },
            { icon: <Clock size={15} color="#6B7280" />, label: "운영시간", value: "09:00 ~ 18:00 (주말 포함)" },
            { icon: <Phone size={15} color="#6B7280" />, label: "전화번호", value: "02-917-4567" },
            { icon: <Navigation size={15} color="#6B7280" />, label: "거리", value: "220m · 도보 3분" },
          ].map((item) => (
            <div key={item.label} style={{ display: "flex", gap: 10, marginBottom: 12, alignItems: "flex-start" }}>
              <div style={{ marginTop: 1 }}>{item.icon}</div>
              <div>
                <div style={{ fontSize: 12, color: "#9CA3AF" }}>{item.label}</div>
                <div style={{ fontSize: 13, fontWeight: 500, color: "#111827", marginTop: 1 }}>{item.value}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Status */}
        <div style={{ background: "#fff", borderRadius: 18, padding: "16px", boxShadow: "0 1px 8px rgba(0,0,0,0.05)" }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: "#111827", marginBottom: 12 }}>운영 상태</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            {[
              { label: "운영 여부", value: "운영 중", ok: true },
              { label: "냉방 상태", value: "쾌적", ok: true },
              { label: "난방 상태", value: "미운영", ok: null },
              { label: "혼잡도", value: "낮음", ok: true },
            ].map((item) => (
              <div key={item.label} style={{ background: "#F8FAFC", borderRadius: 12, padding: "12px" }}>
                <div style={{ fontSize: 11, color: "#9CA3AF", marginBottom: 5 }}>{item.label}</div>
                <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
                  {item.ok === true && <CheckCircle size={14} color="#059669" />}
                  {item.ok === false && <XCircle size={14} color="#EF4444" />}
                  <span style={{ fontSize: 13, fontWeight: 600, color: item.ok === true ? "#059669" : item.ok === false ? "#EF4444" : "#9CA3AF" }}>
                    {item.value}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Amenities */}
        <div style={{ background: "#fff", borderRadius: 18, padding: "16px", boxShadow: "0 1px 8px rgba(0,0,0,0.05)" }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: "#111827", marginBottom: 12 }}>편의 정보</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {[
              { icon: <Droplets size={16} color="#0369A1" />, label: "물 제공", available: true },
              { icon: <Accessibility size={16} color="#7C3AED" />, label: "휠체어 접근 가능", available: true },
              { icon: <PawPrint size={16} color="#F97316" />, label: "반려동물 동반", available: false },
            ].map((item) => (
              <div key={item.label} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 0", borderBottom: "1px solid #F3F4F6" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  {item.icon}
                  <span style={{ fontSize: 13, fontWeight: 500, color: "#374151" }}>{item.label}</span>
                </div>
                <span style={{
                  background: item.available ? "#ECFDF5" : "#F3F4F6",
                  color: item.available ? "#059669" : "#9CA3AF",
                  borderRadius: 20,
                  padding: "3px 10px",
                  fontSize: 12,
                  fontWeight: 600,
                }}>
                  {item.available ? "가능" : "불가"}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Recent reports */}
        <div style={{ background: "#fff", borderRadius: 18, padding: "16px", boxShadow: "0 1px 8px rgba(0,0,0,0.05)" }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: "#111827", marginBottom: 12 }}>최근 이용자 제보</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {[
              { time: "30분 전", icon: "❄️", msg: "냉방 잘 되고 자리 여유 많아요" },
              { time: "2시간 전", icon: "💧", msg: "물 제공 있어요. 직원분들 친절해요" },
              { time: "5시간 전", icon: "♿", msg: "휠체어 진입 편리해요" },
            ].map((r) => (
              <div key={r.time} style={{ display: "flex", gap: 10, paddingBottom: 10, borderBottom: "1px solid #F3F4F6" }}>
                <span style={{ fontSize: 18 }}>{r.icon}</span>
                <div>
                  <div style={{ fontSize: 13, color: "#374151" }}>{r.msg}</div>
                  <div style={{ fontSize: 11, color: "#9CA3AF", marginTop: 3 }}>{r.time}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom actions */}
        <div style={{ display: "flex", gap: 10 }}>
          <button style={{ flex: 1, background: "#1D6FE8", color: "#fff", border: "none", borderRadius: 14, padding: "14px 0", fontSize: 14, fontWeight: 700, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}>
            <Navigation size={17} />
            경로 보기
          </button>
          <button style={{ background: "#FFF7ED", color: "#F97316", border: "none", borderRadius: 14, padding: "14px 20px", fontSize: 14, fontWeight: 600, cursor: "pointer", display: "flex", alignItems: "center", gap: 6 }}>
            <Bell size={17} />
            제보
          </button>
          <button style={{ background: "#F4F7FB", color: "#374151", border: "none", borderRadius: 14, padding: "14px 16px", fontSize: 14, cursor: "pointer" }}>
            <Star size={17} />
          </button>
        </div>
      </div>
    </div>
  );
}
