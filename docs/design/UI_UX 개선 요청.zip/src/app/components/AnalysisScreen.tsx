import { useState } from "react";
import { ChevronDown, ChevronUp, Info } from "lucide-react";

export function AnalysisScreen() {
  const [expanded, setExpanded] = useState(false);

  const riskAreas = [
    { name: "대구", score: 71.1, bar: 100 },
    { name: "서울", score: 48.63, bar: 68 },
    { name: "대전", score: 39.73, bar: 56 },
    { name: "광주", score: 33.04, bar: 46 },
    { name: "부산", score: 24.21, bar: 34 },
  ];

  const scoreFactors = [
    { label: "거리", icon: "📍", weight: 30, desc: "가까울수록 높은 점수" },
    { label: "운영 여부", icon: "🕐", weight: 25, desc: "현재 운영 중인 경우" },
    { label: "혼잡도", icon: "👥", weight: 20, desc: "여유 있을수록 높은 점수" },
    { label: "냉방 상태", icon: "❄️", weight: 15, desc: "냉방 쾌적 시 점수 가산" },
    { label: "접근성", icon: "♿", weight: 5, desc: "휠체어 접근 가능 여부" },
    { label: "사용자 맞춤 조건", icon: "⚙️", weight: 5, desc: "설정한 내 상황 반영" },
  ];

  return (
    <div style={{ flex: 1, overflowY: "auto", background: "#F4F7FB" }}>
      {/* Header */}
      <div
        style={{
          background: "linear-gradient(135deg, #1D6FE8 0%, #1558C0 100%)",
          paddingTop: 52,
          paddingBottom: 24,
          paddingLeft: 20,
          paddingRight: 20,
        }}
      >
        <div style={{ color: "rgba(255,255,255,0.75)", fontSize: 12, marginBottom: 4 }}>
          추천 근거
        </div>
        <div style={{ color: "#fff", fontSize: 20, fontWeight: 700, marginBottom: 10 }}>
          왜 이 쉼터를 추천했나요?
        </div>
        <div style={{ color: "rgba(255,255,255,0.85)", fontSize: 13, lineHeight: 1.6 }}>
          기온, 폭염일수, 온열질환 발생, 고령인구 비율을 바탕으로 지역별 위험도를 계산합니다.
          이 위험도와 내 조건을 함께 고려해 가장 적합한 쉼터를 추천합니다.
        </div>
      </div>

      <div style={{ padding: "16px 16px 32px", display: "flex", flexDirection: "column", gap: 12 }}>

        {/* Current risk summary */}
        <div style={{ background: "#fff", borderRadius: 18, padding: "18px 16px", boxShadow: "0 1px 8px rgba(0,0,0,0.05)" }}>
          <SectionTitle icon="🌡" title="현재 폭염 위험 요약" />
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginTop: 14 }}>
            {[
              { label: "현재 기온", value: "34.2°C", sub: "서울 성북구", color: "#EF4444", bg: "#FEF2F2" },
              { label: "체감온도", value: "37.6°C", sub: "불쾌지수 높음", color: "#F97316", bg: "#FFF7ED" },
              { label: "습도", value: "68%", sub: "고습 주의", color: "#0369A1", bg: "#E0F2FE" },
              { label: "폭염 위험도", value: "높음", sub: "쉼터 이동 권장", color: "#DC2626", bg: "#FEF2F2" },
            ].map((item) => (
              <div key={item.label} style={{ background: item.bg, borderRadius: 12, padding: "12px 12px" }}>
                <div style={{ fontSize: 11, color: "#6B7280", marginBottom: 4 }}>{item.label}</div>
                <div style={{ fontSize: 20, fontWeight: 700, color: item.color }}>{item.value}</div>
                <div style={{ fontSize: 11, color: "#9CA3AF", marginTop: 2 }}>{item.sub}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Regional risk top 5 */}
        <div style={{ background: "#fff", borderRadius: 18, padding: "18px 16px", boxShadow: "0 1px 8px rgba(0,0,0,0.05)" }}>
          <SectionTitle icon="📊" title="지역별 폭염 위험도 TOP 5" />
          <div style={{ marginTop: 14, display: "flex", flexDirection: "column", gap: 10 }}>
            {riskAreas.map((area, i) => (
              <div key={area.name}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <span
                      style={{
                        width: 22,
                        height: 22,
                        background: i === 0 ? "#EF4444" : i === 1 ? "#F97316" : "#F4F7FB",
                        color: i < 2 ? "#fff" : "#6B7280",
                        borderRadius: "50%",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        fontSize: 11,
                        fontWeight: 700,
                        flexShrink: 0,
                      }}
                    >
                      {i + 1}
                    </span>
                    <span style={{ fontSize: 14, fontWeight: 600, color: "#111827" }}>{area.name}</span>
                  </div>
                  <span style={{ fontSize: 14, fontWeight: 700, color: i === 0 ? "#EF4444" : i === 1 ? "#F97316" : "#374151" }}>
                    {area.score}
                  </span>
                </div>
                <div style={{ height: 6, background: "#F3F4F6", borderRadius: 10, overflow: "hidden" }}>
                  <div
                    style={{
                      height: "100%",
                      width: `${area.bar}%`,
                      background: i === 0 ? "#EF4444" : i === 1 ? "#F97316" : "#1D6FE8",
                      borderRadius: 10,
                      transition: "width 0.6s ease",
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Heat illness basis */}
        <div style={{ background: "#fff", borderRadius: 18, padding: "18px 16px", boxShadow: "0 1px 8px rgba(0,0,0,0.05)" }}>
          <SectionTitle icon="🏥" title="온열질환 위험 근거" />
          <div style={{ marginTop: 14, display: "flex", flexDirection: "column", gap: 10 }}>
            {[
              { label: "총 온열질환자 수", value: "2,516명", icon: "👤" },
              { label: "최고기온 33℃ 이상 일수", value: "706일", icon: "☀️" },
              { label: "기온-온열질환 상관계수", value: "0.4057", icon: "📈" },
            ].map((item) => (
              <div
                key={item.label}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 12,
                  padding: "12px 12px",
                  background: "#F8FAFC",
                  borderRadius: 12,
                }}
              >
                <span style={{ fontSize: 20 }}>{item.icon}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 12, color: "#6B7280" }}>{item.label}</div>
                </div>
                <div style={{ fontSize: 16, fontWeight: 700, color: "#1D6FE8" }}>{item.value}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Score factors */}
        <div style={{ background: "#fff", borderRadius: 18, padding: "18px 16px", boxShadow: "0 1px 8px rgba(0,0,0,0.05)" }}>
          <SectionTitle icon="🎯" title="추천 점수 계산 기준" />
          <div style={{ marginTop: 14, display: "flex", flexDirection: "column", gap: 8 }}>
            {scoreFactors.map((f) => (
              <div key={f.label} style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <span style={{ fontSize: 18, width: 28, textAlign: "center" }}>{f.icon}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                    <span style={{ fontSize: 13, fontWeight: 600, color: "#111827" }}>{f.label}</span>
                    <span style={{ fontSize: 12, color: "#1D6FE8", fontWeight: 600 }}>{f.weight}%</span>
                  </div>
                  <div style={{ height: 5, background: "#F3F4F6", borderRadius: 10, overflow: "hidden" }}>
                    <div style={{ height: "100%", width: `${f.weight * 3}%`, background: "#1D6FE8", borderRadius: 10 }} />
                  </div>
                  <div style={{ fontSize: 11, color: "#9CA3AF", marginTop: 3 }}>{f.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Detail toggle */}
        <button
          onClick={() => setExpanded(!expanded)}
          style={{
            background: "#fff",
            border: "none",
            borderRadius: 14,
            padding: "14px 16px",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            cursor: "pointer",
            boxShadow: "0 1px 6px rgba(0,0,0,0.05)",
            width: "100%",
          }}
        >
          <span style={{ fontSize: 13, fontWeight: 600, color: "#374151", display: "flex", alignItems: "center", gap: 6 }}>
            <Info size={15} color="#1D6FE8" />
            상세 분석 데이터 보기
          </span>
          {expanded ? <ChevronUp size={16} color="#9CA3AF" /> : <ChevronDown size={16} color="#9CA3AF" />}
        </button>

        {expanded && (
          <div style={{ background: "#fff", borderRadius: 18, padding: "18px 16px", boxShadow: "0 1px 8px rgba(0,0,0,0.05)" }}>
            <div style={{ fontSize: 13, color: "#6B7280", lineHeight: 1.8 }}>
              <p style={{ margin: 0, marginBottom: 10 }}>
                <strong style={{ color: "#111827" }}>데이터 출처:</strong> 기상청 AWS 관측 데이터, 보건복지부 온열질환 감시체계, 행정안전부 고령인구 통계
              </p>
              <p style={{ margin: 0, marginBottom: 10 }}>
                <strong style={{ color: "#111827" }}>위험도 산출 방법:</strong> 일최고기온, 폭염일수, 온열질환자 발생 수, 65세 이상 고령인구 비율을 정규화하여 가중합산
              </p>
              <p style={{ margin: 0 }}>
                <strong style={{ color: "#111827" }}>업데이트 주기:</strong> 기상 데이터 매 1시간, 쉼터 상태 실시간 시민 제보 기반 갱신
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function SectionTitle({ icon, title }: { icon: string; title: string }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
      <span style={{ fontSize: 18 }}>{icon}</span>
      <span style={{ fontSize: 15, fontWeight: 700, color: "#111827" }}>{title}</span>
    </div>
  );
}
