import { useState } from "react";
import {
  Search,
  Navigation,
  ChevronUp,
  CheckCircle,
  Wind,
  Users,
  Clock,
  X,
} from "lucide-react";

interface Marker {
  id: string;
  x: number;
  y: number;
  type: "cooling" | "heating" | "public" | "private";
  name: string;
  distance: string;
  walk: string;
  open: boolean;
  score: number;
  cooling: string;
  crowding: string;
}

const markers: Marker[] = [
  { id: "1", x: 50, y: 52, type: "cooling", name: "성북종합사회복지관", distance: "220m", walk: "3분", open: true, score: 92, cooling: "쾌적", crowding: "낮음" },
  { id: "2", x: 68, y: 35, type: "public", name: "성북구청 민원실", distance: "380m", walk: "5분", open: true, score: 85, cooling: "쾌적", crowding: "보통" },
  { id: "3", x: 28, y: 42, type: "cooling", name: "성북 어린이도서관", distance: "620m", walk: "8분", open: true, score: 78, cooling: "보통", crowding: "낮음" },
  { id: "4", x: 72, y: 65, type: "private", name: "GS25 편의점", distance: "150m", walk: "2분", open: true, score: 61, cooling: "쾌적", crowding: "낮음" },
  { id: "5", x: 38, y: 72, type: "public", name: "성북 주민센터", distance: "800m", walk: "10분", open: false, score: 55, cooling: "-", crowding: "-" },
  { id: "6", x: 85, y: 48, type: "heating", name: "성북 보건소", distance: "950m", walk: "12분", open: true, score: 72, cooling: "보통", crowding: "낮음" },
];

const typeColor: Record<string, string> = {
  cooling: "#1D6FE8",
  heating: "#F97316",
  public: "#059669",
  private: "#7C3AED",
};

const typeLabel: Record<string, string> = {
  cooling: "냉방쉼터",
  heating: "온열쉼터",
  public: "공공시설",
  private: "민간쉼터",
};

const filters = ["전체", "냉방쉼터", "온열쉼터", "공공시설", "민간쉼터"];

export function MapScreen() {
  const [activeFilter, setActiveFilter] = useState("전체");
  const [selectedMarker, setSelectedMarker] = useState<Marker | null>(null);
  const [showRecommended, setShowRecommended] = useState(false);

  const filteredMarkers = markers.filter(
    (m) =>
      activeFilter === "전체" || typeLabel[m.type] === activeFilter
  );

  const recommended = markers.find((m) => m.id === "1")!;

  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", position: "relative", overflow: "hidden" }}>
      {/* Search bar */}
      <div
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          zIndex: 10,
          padding: "52px 16px 12px",
          background: "linear-gradient(to bottom, rgba(244,247,251,0.98) 70%, transparent)",
        }}
      >
        <div
          style={{
            background: "#fff",
            borderRadius: 14,
            display: "flex",
            alignItems: "center",
            gap: 10,
            padding: "11px 14px",
            boxShadow: "0 2px 12px rgba(0,0,0,0.1)",
          }}
        >
          <Search size={17} color="#9CA3AF" />
          <span style={{ fontSize: 14, color: "#9CA3AF" }}>장소를 검색하세요</span>
        </div>

        {/* Filter chips */}
        <div
          style={{
            display: "flex",
            gap: 7,
            marginTop: 10,
            overflowX: "auto",
            paddingBottom: 2,
          }}
        >
          {filters.map((f) => (
            <button
              key={f}
              onClick={() => setActiveFilter(f)}
              style={{
                border: "none",
                borderRadius: 20,
                padding: "6px 14px",
                fontSize: 12,
                fontWeight: 600,
                whiteSpace: "nowrap",
                cursor: "pointer",
                background: activeFilter === f ? "#1D6FE8" : "#fff",
                color: activeFilter === f ? "#fff" : "#374151",
                boxShadow: "0 1px 6px rgba(0,0,0,0.08)",
                transition: "all 0.15s",
              }}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* Map */}
      <div style={{ flex: 1, position: "relative" }}>
        <svg
          width="100%"
          height="100%"
          viewBox="0 0 100 100"
          preserveAspectRatio="xMidYMid slice"
          style={{ display: "block" }}
        >
          {/* Background */}
          <rect width="100" height="100" fill="#E8EDF4" />

          {/* Blocks */}
          {cityBlocks.map((b, i) => (
            <rect key={i} x={b.x} y={b.y} width={b.w} height={b.h} rx={0.5} fill={b.fill} />
          ))}

          {/* Roads */}
          {roads.map((r, i) => (
            <line key={i} x1={r.x1} y1={r.y1} x2={r.x2} y2={r.y2} stroke="#D1D8E4" strokeWidth={r.width} />
          ))}

          {/* Park */}
          <rect x="18" y="58" width="12" height="10" rx="1" fill="#BBE5C8" />
          <rect x="56" y="20" width="8" height="8" rx="1" fill="#C8E6C9" />

          {/* My location */}
          <circle cx="50" cy="52" r="2.5" fill="#fff" stroke="#1D6FE8" strokeWidth="1.5" />
          <circle cx="50" cy="52" r="1.2" fill="#1D6FE8" />
          <circle cx="50" cy="52" r="5" fill="#1D6FE8" fillOpacity="0.15" />

          {/* Markers */}
          {filteredMarkers.map((m) => (
            <g key={m.id} onClick={() => { setSelectedMarker(m); setShowRecommended(false); }} style={{ cursor: "pointer" }}>
              <circle
                cx={m.x}
                cy={m.y}
                r={m.id === selectedMarker?.id ? 4 : 3.2}
                fill={typeColor[m.type]}
                stroke="#fff"
                strokeWidth="1.2"
                opacity={m.open ? 1 : 0.5}
              />
              {m.id === "1" && (
                <>
                  <circle cx={m.x} cy={m.y} r={5.5} fill="#1D6FE8" fillOpacity="0.15" />
                  <text x={m.x} y={m.y - 5} textAnchor="middle" fontSize="3" fill="#1D6FE8" fontWeight="bold">★</text>
                </>
              )}
            </g>
          ))}
        </svg>

        {/* Legend */}
        <div
          style={{
            position: "absolute",
            bottom: showRecommended || selectedMarker ? 200 : 80,
            right: 12,
            background: "#fff",
            borderRadius: 12,
            padding: "10px 12px",
            boxShadow: "0 2px 12px rgba(0,0,0,0.1)",
            transition: "bottom 0.3s",
          }}
        >
          {Object.entries(typeColor).map(([key, color]) => (
            <div key={key} style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 5 }}>
              <div style={{ width: 8, height: 8, borderRadius: "50%", background: color }} />
              <span style={{ fontSize: 11, color: "#374151" }}>{typeLabel[key]}</span>
            </div>
          ))}
        </div>

        {/* Find best shelter button */}
        {!showRecommended && !selectedMarker && (
          <button
            onClick={() => setShowRecommended(true)}
            style={{
              position: "absolute",
              bottom: 16,
              left: "50%",
              transform: "translateX(-50%)",
              background: "#1D6FE8",
              color: "#fff",
              border: "none",
              borderRadius: 30,
              padding: "13px 28px",
              fontSize: 14,
              fontWeight: 700,
              cursor: "pointer",
              boxShadow: "0 4px 20px rgba(29,111,232,0.4)",
              display: "flex",
              alignItems: "center",
              gap: 8,
              whiteSpace: "nowrap",
            }}
          >
            <Navigation size={16} />
            내 위치 기준 최적 쉼터 찾기
          </button>
        )}
      </div>

      {/* Selected marker card */}
      {selectedMarker && (
        <div
          style={{
            background: "#fff",
            borderTopLeftRadius: 20,
            borderTopRightRadius: 20,
            padding: "16px 16px 24px",
            boxShadow: "0 -4px 20px rgba(0,0,0,0.08)",
          }}
        >
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
            <div>
              <div style={{ fontSize: 16, fontWeight: 700, color: "#111827" }}>{selectedMarker.name}</div>
              <div style={{ fontSize: 12, color: "#6B7280", marginTop: 2 }}>
                {selectedMarker.distance} · 도보 {selectedMarker.walk}
              </div>
            </div>
            <button onClick={() => setSelectedMarker(null)} style={{ border: "none", background: "none", cursor: "pointer" }}>
              <X size={18} color="#9CA3AF" />
            </button>
          </div>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 12 }}>
            <MiniTag icon={<CheckCircle size={12} />} label={selectedMarker.open ? "운영 중" : "운영 종료"} color={selectedMarker.open ? "#059669" : "#EF4444"} bg={selectedMarker.open ? "#ECFDF5" : "#FEF2F2"} />
            <MiniTag icon={<Wind size={12} />} label={`냉방 ${selectedMarker.cooling}`} color="#0369A1" bg="#E0F2FE" />
            <MiniTag icon={<Users size={12} />} label={`혼잡도 ${selectedMarker.crowding}`} color="#059669" bg="#ECFDF5" />
            <MiniTag icon={<Clock size={12} />} label={selectedMarker.walk} color="#6B7280" bg="#F3F4F6" />
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <button style={{ flex: 1, background: "#1D6FE8", color: "#fff", border: "none", borderRadius: 12, padding: "11px 0", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>
              경로 보기
            </button>
            <button style={{ flex: 1, background: "#F4F7FB", color: "#374151", border: "none", borderRadius: 12, padding: "11px 0", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>
              상세 보기
            </button>
            <button style={{ background: "#FFF7ED", color: "#F97316", border: "none", borderRadius: 12, padding: "11px 14px", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>
              제보
            </button>
          </div>
        </div>
      )}

      {/* Recommended shelter card */}
      {showRecommended && (
        <div
          style={{
            background: "#fff",
            borderTopLeftRadius: 20,
            borderTopRightRadius: 20,
            padding: "16px 16px 24px",
            boxShadow: "0 -4px 20px rgba(0,0,0,0.08)",
          }}
        >
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: "#1D6FE8" }}>
              📍 내 위치 기준 추천 쉼터
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <div style={{ background: "#1D6FE8", color: "#fff", borderRadius: 20, padding: "2px 10px", fontSize: 12, fontWeight: 700 }}>
                {recommended.score}점
              </div>
              <button onClick={() => setShowRecommended(false)} style={{ border: "none", background: "none", cursor: "pointer" }}>
                <X size={16} color="#9CA3AF" />
              </button>
            </div>
          </div>
          <div style={{ fontSize: 17, fontWeight: 700, color: "#111827", marginBottom: 8 }}>
            {recommended.name}
          </div>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 12 }}>
            <MiniTag icon={<CheckCircle size={12} />} label="운영 중" color="#059669" bg="#ECFDF5" />
            <MiniTag icon={<Clock size={12} />} label={`도보 ${recommended.walk} · ${recommended.distance}`} color="#6B7280" bg="#F3F4F6" />
            <MiniTag icon={<Wind size={12} />} label={`냉방 ${recommended.cooling}`} color="#0369A1" bg="#E0F2FE" />
            <MiniTag icon={<Users size={12} />} label={`혼잡도 ${recommended.crowding}`} color="#059669" bg="#ECFDF5" />
          </div>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 14 }}>
            {["가까움", "운영 중", "냉방 쾌적", "물 제공", "휠체어 접근"].map((t) => (
              <span key={t} style={{ background: "#EFF4FF", color: "#1D6FE8", borderRadius: 20, padding: "3px 10px", fontSize: 11, fontWeight: 500 }}>
                {t}
              </span>
            ))}
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <button style={{ flex: 1, background: "#1D6FE8", color: "#fff", border: "none", borderRadius: 12, padding: "12px 0", fontSize: 14, fontWeight: 700, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}>
              <Navigation size={16} /> 경로 보기
            </button>
            <button style={{ background: "#F4F7FB", color: "#374151", border: "none", borderRadius: 12, padding: "12px 16px", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>
              상세
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function MiniTag({ icon, label, color, bg }: { icon: React.ReactNode; label: string; color: string; bg: string }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 4, background: bg, color, borderRadius: 20, padding: "3px 9px", fontSize: 12, fontWeight: 500 }}>
      {icon}{label}
    </div>
  );
}

const cityBlocks = [
  { x: 0, y: 0, w: 15, h: 20, fill: "#DDE3ED" },
  { x: 17, y: 0, w: 30, h: 15, fill: "#D5DCE8" },
  { x: 49, y: 0, w: 20, h: 12, fill: "#DDE3ED" },
  { x: 71, y: 0, w: 29, h: 18, fill: "#D8DEE9" },
  { x: 0, y: 22, w: 14, h: 20, fill: "#D5DCE8" },
  { x: 17, y: 17, w: 12, h: 22, fill: "#DDE3ED" },
  { x: 31, y: 17, w: 16, h: 22, fill: "#D5DCE8" },
  { x: 49, y: 14, w: 20, h: 18, fill: "#DDE3ED" },
  { x: 71, y: 20, w: 12, h: 18, fill: "#D5DCE8" },
  { x: 85, y: 20, w: 15, h: 18, fill: "#DDE3ED" },
  { x: 0, y: 44, w: 16, h: 12, fill: "#D8DEE9" },
  { x: 18, y: 44, w: 10, h: 12, fill: "#DDE3ED" },
  { x: 30, y: 41, w: 18, h: 12, fill: "#D5DCE8" },
  { x: 52, y: 41, w: 16, h: 12, fill: "#DDE3ED" },
  { x: 70, y: 41, w: 14, h: 12, fill: "#D5DCE8" },
  { x: 86, y: 41, w: 14, h: 12, fill: "#D8DEE9" },
  { x: 0, y: 58, w: 16, h: 12, fill: "#D5DCE8" },
  { x: 32, y: 58, w: 20, h: 12, fill: "#DDE3ED" },
  { x: 54, y: 58, w: 14, h: 12, fill: "#D5DCE8" },
  { x: 70, y: 58, w: 14, h: 12, fill: "#DDE3ED" },
  { x: 86, y: 58, w: 14, h: 12, fill: "#D5DCE8" },
  { x: 0, y: 72, w: 20, h: 28, fill: "#D8DEE9" },
  { x: 22, y: 72, w: 18, h: 28, fill: "#D5DCE8" },
  { x: 42, y: 72, w: 16, h: 28, fill: "#DDE3ED" },
  { x: 60, y: 72, w: 18, h: 28, fill: "#D5DCE8" },
  { x: 80, y: 72, w: 20, h: 28, fill: "#D8DEE9" },
];

const roads = [
  { x1: 0, y1: 16, x2: 100, y2: 16, width: 1.5 },
  { x1: 0, y1: 40, x2: 100, y2: 40, width: 2 },
  { x1: 0, y1: 57, x2: 100, y2: 57, width: 1.5 },
  { x1: 0, y1: 71, x2: 100, y2: 71, width: 2 },
  { x1: 16, y1: 0, x2: 16, y2: 100, width: 1.5 },
  { x1: 30, y1: 0, x2: 30, y2: 100, width: 1 },
  { x1: 48, y1: 0, x2: 48, y2: 100, width: 2 },
  { x1: 70, y1: 0, x2: 70, y2: 100, width: 1.5 },
  { x1: 85, y1: 0, x2: 85, y2: 100, width: 1 },
];
