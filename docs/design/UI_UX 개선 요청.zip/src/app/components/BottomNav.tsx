import { Home, Map, BarChart2, Star, User } from "lucide-react";

type Tab = "home" | "map" | "analysis" | "favorites" | "my";

interface BottomNavProps {
  activeTab: Tab;
  onTabChange: (tab: Tab) => void;
}

const tabs = [
  { id: "home" as Tab, label: "홈", Icon: Home },
  { id: "map" as Tab, label: "지도", Icon: Map },
  { id: "analysis" as Tab, label: "추천근거", Icon: BarChart2 },
  { id: "favorites" as Tab, label: "즐겨찾기", Icon: Star },
  { id: "my" as Tab, label: "마이", Icon: User },
];

export function BottomNav({ activeTab, onTabChange }: BottomNavProps) {
  return (
    <div
      style={{
        background: "#fff",
        borderTop: "1px solid rgba(0,0,0,0.07)",
        display: "flex",
        paddingBottom: "env(safe-area-inset-bottom, 0px)",
      }}
    >
      {tabs.map(({ id, label, Icon }) => {
        const active = activeTab === id;
        return (
          <button
            key={id}
            onClick={() => onTabChange(id)}
            style={{
              flex: 1,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              gap: 3,
              paddingTop: 10,
              paddingBottom: 10,
              border: "none",
              background: "none",
              cursor: "pointer",
              color: active ? "#1D6FE8" : "#9CA3AF",
              transition: "color 0.15s",
            }}
          >
            <Icon size={22} strokeWidth={active ? 2.2 : 1.8} />
            <span
              style={{
                fontSize: 10,
                fontWeight: active ? 600 : 400,
                lineHeight: 1,
              }}
            >
              {label}
            </span>
          </button>
        );
      })}
    </div>
  );
}
