import { Star, Navigation, CheckCircle, Clock, Wind, ChevronRight } from "lucide-react";

const favorites = [
  {
    id: "1",
    icon: "🏢",
    name: "성북종합사회복지관",
    address: "서울 성북구 동소문로 47",
    distance: "220m",
    walk: "3분",
    open: true,
    score: 92,
    cooling: "쾌적",
  },
  {
    id: "2",
    icon: "📚",
    name: "성북 어린이도서관",
    address: "서울 성북구 화랑로 32",
    distance: "620m",
    walk: "8분",
    open: true,
    score: 78,
    cooling: "보통",
  },
  {
    id: "3",
    icon: "🏛",
    name: "성북구립 미아리고개도서관",
    address: "서울 성북구 종암로 126",
    distance: "1.1km",
    walk: "14분",
    open: false,
    score: 65,
    cooling: "-",
  },
];

export function FavoritesScreen() {
  return (
    <div style={{ flex: 1, overflowY: "auto", background: "#F4F7FB" }}>
      {/* Header */}
      <div
        style={{
          background: "linear-gradient(135deg, #1D6FE8 0%, #1558C0 100%)",
          paddingTop: 52,
          paddingBottom: 24,
          paddingLeft: 20,
          paddingRight: 20,
        }}
      >
        <div style={{ color: "rgba(255,255,255,0.75)", fontSize: 12, marginBottom: 4 }}>
          즐겨찾기
        </div>
        <div style={{ color: "#fff", fontSize: 20, fontWeight: 700 }}>
          자주 찾는 쉼터
        </div>
      </div>

      <div style={{ padding: "16px 16px 32px" }}>
        {favorites.length === 0 ? (
          <div style={{ textAlign: "center", padding: "60px 20px", color: "#9CA3AF" }}>
            <Star size={40} style={{ margin: "0 auto 12px", display: "block" }} />
            <div style={{ fontSize: 16, fontWeight: 600, color: "#374151", marginBottom: 6 }}>
              즐겨찾기한 쉼터가 없습니다
            </div>
            <div style={{ fontSize: 13 }}>
              자주 이용하는 쉼터를 즐겨찾기에 추가해 보세요
            </div>
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {favorites.map((s) => (
              <div
                key={s.id}
                style={{
                  background: "#fff",
                  borderRadius: 18,
                  padding: "16px 16px",
                  boxShadow: "0 1px 8px rgba(0,0,0,0.05)",
                }}
              >
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
                  <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
                    <div
                      style={{
                        width: 44,
                        height: 44,
                        background: "#EFF4FF",
                        borderRadius: 12,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        fontSize: 22,
                        flexShrink: 0,
                      }}
                    >
                      {s.icon}
                    </div>
                    <div>
                      <div style={{ fontSize: 15, fontWeight: 700, color: "#111827" }}>{s.name}</div>
                      <div style={{ fontSize: 12, color: "#9CA3AF", marginTop: 2 }}>{s.address}</div>
                    </div>
                  </div>
                  <Star size={18} color="#F59E0B" fill="#F59E0B" style={{ flexShrink: 0 }} />
                </div>

                {/* Status */}
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 12 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 4, background: s.open ? "#ECFDF5" : "#FEF2F2", color: s.open ? "#059669" : "#EF4444", borderRadius: 20, padding: "3px 9px", fontSize: 12, fontWeight: 500 }}>
                    <CheckCircle size={12} />{s.open ? "운영 중" : "운영 종료"}
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 4, background: "#F3F4F6", color: "#6B7280", borderRadius: 20, padding: "3px 9px", fontSize: 12, fontWeight: 500 }}>
                    <Clock size={12} />{s.walk} · {s.distance}
                  </div>
                  {s.open && (
                    <div style={{ display: "flex", alignItems: "center", gap: 4, background: "#E0F2FE", color: "#0369A1", borderRadius: 20, padding: "3px 9px", fontSize: 12, fontWeight: 500 }}>
                      <Wind size={12} />냉방 {s.cooling}
                    </div>
                  )}
                  <div style={{ background: "#EFF4FF", color: "#1D6FE8", borderRadius: 20, padding: "3px 9px", fontSize: 12, fontWeight: 700, marginLeft: "auto" }}>
                    {s.score}점
                  </div>
                </div>

                <div style={{ display: "flex", gap: 8 }}>
                  <button style={{ flex: 1, background: s.open ? "#1D6FE8" : "#E5E7EB", color: s.open ? "#fff" : "#9CA3AF", border: "none", borderRadius: 10, padding: "10px 0", fontSize: 13, fontWeight: 600, cursor: s.open ? "pointer" : "default", display: "flex", alignItems: "center", justifyContent: "center", gap: 5 }}>
                    <Navigation size={14} />
                    경로 보기
                  </button>
                  <button style={{ background: "#F4F7FB", color: "#374151", border: "none", borderRadius: 10, padding: "10px 14px", fontSize: 13, fontWeight: 600, cursor: "pointer", display: "flex", alignItems: "center", gap: 4 }}>
                    상세 <ChevronRight size={13} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
