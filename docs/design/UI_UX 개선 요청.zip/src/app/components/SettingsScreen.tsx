import { useState } from "react";
import { CheckCircle } from "lucide-react";

const conditions = [
  { id: "elderly", icon: "👴", label: "어르신" },
  { id: "infant", icon: "👶", label: "영유아 동반" },
  { id: "disabled", icon: "♿", label: "장애인" },
  { id: "outdoor", icon: "👷", label: "야외근로자" },
  { id: "pregnant", icon: "🤰", label: "임산부" },
  { id: "pet", icon: "🐾", label: "반려동물 동반" },
  { id: "mobility", icon: "🦯", label: "보행이 불편함" },
  { id: "transit", icon: "🚌", label: "대중교통 이용" },
];

const routePrefs = [
  { id: "shortest", icon: "📍", label: "최단 거리 우선" },
  { id: "accessible", icon: "🛗", label: "계단/경사 최소화" },
  { id: "shade", icon: "🌳", label: "그늘길/실내 경유 우선" },
];

export function SettingsScreen() {
  const [selected, setSelected] = useState<Set<string>>(new Set(["elderly"]));
  const [route, setRoute] = useState("shortest");
  const [saved, setSaved] = useState(false);

  const toggle = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
    setSaved(false);
  };

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div style={{ flex: 1, overflowY: "auto", background: "#F4F7FB" }}>
      {/* Header */}
      <div
        style={{
          background: "linear-gradient(135deg, #1D6FE8 0%, #1558C0 100%)",
          paddingTop: 52,
          paddingBottom: 24,
          paddingLeft: 20,
          paddingRight: 20,
        }}
      >
        <div style={{ color: "rgba(255,255,255,0.75)", fontSize: 12, marginBottom: 4 }}>
          맞춤 설정
        </div>
        <div style={{ color: "#fff", fontSize: 20, fontWeight: 700, marginBottom: 8 }}>
          내 상황에 맞는 쉼터 찾기
        </div>
        <div
          style={{
            background: "rgba(255,255,255,0.15)",
            borderRadius: 12,
            padding: "10px 14px",
            fontSize: 13,
            color: "rgba(255,255,255,0.9)",
            lineHeight: 1.5,
          }}
        >
          ⚙️ 선택한 조건은 쉼터 추천 점수에 반영됩니다
        </div>
      </div>

      <div style={{ padding: "16px 16px 32px", display: "flex", flexDirection: "column", gap: 14 }}>

        {/* Condition chips */}
        <div style={{ background: "#fff", borderRadius: 18, padding: "18px 16px", boxShadow: "0 1px 8px rgba(0,0,0,0.05)" }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: "#111827", marginBottom: 6 }}>
            해당하는 항목을 선택하세요
          </div>
          <div style={{ fontSize: 12, color: "#9CA3AF", marginBottom: 14 }}>
            복수 선택 가능
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
            {conditions.map((c) => {
              const active = selected.has(c.id);
              return (
                <button
                  key={c.id}
                  onClick={() => toggle(c.id)}
                  style={{
                    border: active ? "2px solid #1D6FE8" : "2px solid #E5E7EB",
                    borderRadius: 14,
                    padding: "12px 12px",
                    background: active ? "#EFF4FF" : "#F8FAFC",
                    cursor: "pointer",
                    display: "flex",
                    alignItems: "center",
                    gap: 8,
                    transition: "all 0.15s",
                  }}
                >
                  <span style={{ fontSize: 20 }}>{c.icon}</span>
                  <span style={{ fontSize: 13, fontWeight: active ? 600 : 400, color: active ? "#1D6FE8" : "#374151" }}>
                    {c.label}
                  </span>
                  {active && (
                    <CheckCircle size={14} color="#1D6FE8" style={{ marginLeft: "auto" }} />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Route preference */}
        <div style={{ background: "#fff", borderRadius: 18, padding: "18px 16px", boxShadow: "0 1px 8px rgba(0,0,0,0.05)" }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: "#111827", marginBottom: 14 }}>
            이동 경로 선호
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {routePrefs.map((r) => {
              const active = route === r.id;
              return (
                <button
                  key={r.id}
                  onClick={() => { setRoute(r.id); setSaved(false); }}
                  style={{
                    border: active ? "2px solid #1D6FE8" : "2px solid #E5E7EB",
                    borderRadius: 14,
                    padding: "14px 14px",
                    background: active ? "#EFF4FF" : "#F8FAFC",
                    cursor: "pointer",
                    display: "flex",
                    alignItems: "center",
                    gap: 10,
                    transition: "all 0.15s",
                  }}
                >
                  <span style={{ fontSize: 22 }}>{r.icon}</span>
                  <span style={{ fontSize: 14, fontWeight: active ? 600 : 400, color: active ? "#1D6FE8" : "#374151" }}>
                    {r.label}
                  </span>
                  {active && <CheckCircle size={16} color="#1D6FE8" style={{ marginLeft: "auto" }} />}
                </button>
              );
            })}
          </div>
        </div>

        {/* Preview */}
        {selected.size > 0 && (
          <div style={{ background: "#EFF4FF", borderRadius: 18, padding: "16px 16px", border: "1px solid #BFDBFE" }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: "#1D6FE8", marginBottom: 8 }}>
              선택한 조건 ({selected.size}개)
            </div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
              {[...selected].map((id) => {
                const c = conditions.find((x) => x.id === id);
                return c ? (
                  <span key={id} style={{ background: "#fff", color: "#1D6FE8", borderRadius: 20, padding: "4px 12px", fontSize: 12, fontWeight: 500, border: "1px solid #BFDBFE" }}>
                    {c.icon} {c.label}
                  </span>
                ) : null;
              })}
            </div>
          </div>
        )}

        {/* Save button */}
        <button
          onClick={handleSave}
          style={{
            background: saved ? "#059669" : "#1D6FE8",
            color: "#fff",
            border: "none",
            borderRadius: 16,
            padding: "16px 0",
            fontSize: 15,
            fontWeight: 700,
            cursor: "pointer",
            transition: "background 0.3s",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
          }}
        >
          {saved ? (
            <>
              <CheckCircle size={18} />
              저장 완료! 추천에 반영됩니다
            </>
          ) : (
            "맞춤 설정 저장"
          )}
        </button>
      </div>
    </div>
  );
}
