import { useState } from "react";
import {
  MapPin,
  Thermometer,
  Droplets,
  Wind,
  ChevronRight,
  Navigation,
  Map,
  Bell,
  Star,
  Settings,
  AlertTriangle,
  CheckCircle,
  Clock,
  Users,
  Snowflake,
} from "lucide-react";

type Tab = "home" | "map" | "analysis" | "favorites" | "my";

interface HomeScreenProps {
  onNavigate: (tab: Tab, detail?: string) => void;
}

const tags = [
  { label: "가까움", color: "#1D6FE8", bg: "#EFF4FF" },
  { label: "운영 중", color: "#059669", bg: "#ECFDF5" },
  { label: "냉방 쾌적", color: "#0369A1", bg: "#E0F2FE" },
  { label: "혼잡도 낮음", color: "#059669", bg: "#ECFDF5" },
  { label: "물 제공", color: "#7C3AED", bg: "#F5F3FF" },
  { label: "휠체어 접근", color: "#D97706", bg: "#FFFBEB" },
];

export function HomeScreen({ onNavigate }: HomeScreenProps) {
  const [mode, setMode] = useState<"heat" | "cold">("heat");

  return (
    <div
      style={{
        flex: 1,
        overflowY: "auto",
        background: "#F4F7FB",
        paddingBottom: 16,
      }}
    >
      {/* Header */}
      <div
        style={{
          background: "linear-gradient(135deg, #1D6FE8 0%, #1558C0 100%)",
          paddingTop: 52,
          paddingBottom: 20,
          paddingLeft: 20,
          paddingRight: 20,
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: 16,
          }}
        >
          <div>
            <div
              style={{
                color: "rgba(255,255,255,0.75)",
                fontSize: 12,
                display: "flex",
                alignItems: "center",
                gap: 4,
                marginBottom: 2,
              }}
            >
              <MapPin size={12} />
              서울 성북구
            </div>
            <div
              style={{ color: "#fff", fontSize: 22, fontWeight: 700 }}
            >
              휴숨
            </div>
          </div>
          <button
            style={{
              background: "rgba(255,255,255,0.15)",
              border: "none",
              borderRadius: 12,
              padding: "8px 8px",
              cursor: "pointer",
            }}
          >
            <Bell size={20} color="#fff" />
          </button>
        </div>

        {/* Mode toggle */}
        <div
          style={{
            background: "rgba(255,255,255,0.15)",
            borderRadius: 30,
            display: "flex",
            padding: 3,
            marginBottom: 16,
          }}
        >
          <button
            onClick={() => setMode("heat")}
            style={{
              flex: 1,
              border: "none",
              borderRadius: 26,
              padding: "6px 0",
              fontSize: 13,
              fontWeight: 600,
              cursor: "pointer",
              background: mode === "heat" ? "#fff" : "transparent",
              color: mode === "heat" ? "#1D6FE8" : "rgba(255,255,255,0.8)",
              transition: "all 0.2s",
            }}
          >
            🌡 폭염
          </button>
          <button
            onClick={() => setMode("cold")}
            style={{
              flex: 1,
              border: "none",
              borderRadius: 26,
              padding: "6px 0",
              fontSize: 13,
              fontWeight: 600,
              cursor: "pointer",
              background: mode === "cold" ? "#fff" : "transparent",
              color: mode === "cold" ? "#0369A1" : "rgba(255,255,255,0.8)",
              transition: "all 0.2s",
            }}
          >
            <Snowflake
              size={13}
              style={{ display: "inline", marginRight: 3 }}
            />
            한파
          </button>
        </div>

        {mode === "cold" && (
          <div
            style={{
              background: "rgba(255,255,255,0.12)",
              borderRadius: 10,
              padding: "10px 14px",
              fontSize: 12,
              color: "rgba(255,255,255,0.85)",
              marginBottom: 10,
            }}
          >
            ❄️ 현재 계절은 폭염 위험이 높습니다. 한파 대비 쉼터 정보는 겨울철 기준으로 제공됩니다.
          </div>
        )}

        {/* Weather row */}
        <div
          style={{
            display: "flex",
            gap: 12,
            alignItems: "center",
          }}
        >
          <div>
            <div
              style={{
                color: "#fff",
                fontSize: 40,
                fontWeight: 700,
                lineHeight: 1,
              }}
            >
              34.2°
            </div>
            <div
              style={{
                color: "rgba(255,255,255,0.7)",
                fontSize: 12,
                marginTop: 2,
              }}
            >
              맑음
            </div>
          </div>
          <div style={{ flex: 1 }} />
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              gap: 6,
              alignItems: "flex-end",
            }}
          >
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 5,
                color: "rgba(255,255,255,0.85)",
                fontSize: 12,
              }}
            >
              <Thermometer size={13} />
              체감 37.6°
            </div>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 5,
                color: "rgba(255,255,255,0.85)",
                fontSize: 12,
              }}
            >
              <Droplets size={13} />
              습도 68%
            </div>
          </div>
        </div>
      </div>

      {/* Danger level banner */}
      <div
        style={{
          margin: "16px 16px 0",
          background: "linear-gradient(135deg, #FF6B35 0%, #EF4444 100%)",
          borderRadius: 14,
          padding: "12px 16px",
          display: "flex",
          alignItems: "center",
          gap: 10,
        }}
      >
        <AlertTriangle size={22} color="#fff" />
        <div>
          <div style={{ color: "#fff", fontSize: 15, fontWeight: 700 }}>
            폭염 위험도: 높음
          </div>
          <div style={{ color: "rgba(255,255,255,0.85)", fontSize: 12 }}>
            지금 바로 쉼터로 이동을 권장합니다
          </div>
        </div>
      </div>

      {/* Best shelter card */}
      <div
        style={{
          margin: "14px 16px 0",
          background: "#fff",
          borderRadius: 18,
          padding: "18px 16px",
          boxShadow: "0 2px 12px rgba(0,0,0,0.06)",
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: 12,
          }}
        >
          <div style={{ fontSize: 13, fontWeight: 600, color: "#1D6FE8" }}>
            📍 내 위치 기준 최적 쉼터
          </div>
          <div
            style={{
              background: "#1D6FE8",
              color: "#fff",
              borderRadius: 20,
              padding: "2px 10px",
              fontSize: 12,
              fontWeight: 700,
            }}
          >
            92점
          </div>
        </div>

        <div style={{ fontSize: 18, fontWeight: 700, color: "#111827", marginBottom: 8 }}>
          성북종합사회복지관
        </div>

        {/* Status row */}
        <div
          style={{
            display: "flex",
            gap: 8,
            marginBottom: 12,
            flexWrap: "wrap",
          }}
        >
          <StatusBadge icon={<CheckCircle size={13} />} label="운영 중" color="#059669" bg="#ECFDF5" />
          <StatusBadge icon={<Clock size={13} />} label="도보 3분 · 220m" color="#6B7280" bg="#F3F4F6" />
          <StatusBadge icon={<Wind size={13} />} label="냉방 쾌적" color="#0369A1" bg="#E0F2FE" />
          <StatusBadge icon={<Users size={13} />} label="혼잡도 낮음" color="#059669" bg="#ECFDF5" />
        </div>

        {/* Score bar */}
        <div style={{ marginBottom: 14 }}>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              marginBottom: 5,
            }}
          >
            <span style={{ fontSize: 12, color: "#6B7280" }}>추천 적합도</span>
            <span style={{ fontSize: 12, fontWeight: 700, color: "#1D6FE8" }}>92 / 100</span>
          </div>
          <div
            style={{
              height: 7,
              background: "#EFF4FF",
              borderRadius: 10,
              overflow: "hidden",
            }}
          >
            <div
              style={{
                height: "100%",
                width: "92%",
                background: "linear-gradient(90deg, #1D6FE8, #60A5FA)",
                borderRadius: 10,
              }}
            />
          </div>
        </div>

        {/* Reason tags */}
        <div
          style={{
            display: "flex",
            flexWrap: "wrap",
            gap: 6,
            marginBottom: 16,
          }}
        >
          {tags.map((t) => (
            <span
              key={t.label}
              style={{
                background: t.bg,
                color: t.color,
                borderRadius: 20,
                padding: "4px 10px",
                fontSize: 12,
                fontWeight: 500,
              }}
            >
              {t.label}
            </span>
          ))}
        </div>

        {/* Action buttons */}
        <div style={{ display: "flex", gap: 8 }}>
          <button
            style={{
              flex: 1,
              background: "#1D6FE8",
              color: "#fff",
              border: "none",
              borderRadius: 12,
              padding: "12px 0",
              fontSize: 14,
              fontWeight: 600,
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 6,
            }}
          >
            <Navigation size={16} />
            안전 경로 보기
          </button>
          <button
            onClick={() => onNavigate("home", "detail")}
            style={{
              background: "#F4F7FB",
              color: "#374151",
              border: "none",
              borderRadius: 12,
              padding: "12px 14px",
              fontSize: 14,
              fontWeight: 600,
              cursor: "pointer",
            }}
          >
            상세
          </button>
        </div>
      </div>

      {/* Secondary actions */}
      <div style={{ display: "flex", gap: 10, margin: "14px 16px 0" }}>
        <button
          onClick={() => onNavigate("map")}
          style={{
            flex: 1,
            background: "#fff",
            border: "none",
            borderRadius: 14,
            padding: "14px 12px",
            fontSize: 13,
            fontWeight: 600,
            color: "#374151",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 6,
            boxShadow: "0 1px 6px rgba(0,0,0,0.05)",
          }}
        >
          <Map size={17} color="#1D6FE8" />
          주변 쉼터 보기
        </button>
        <button
          style={{
            flex: 1,
            background: "#fff",
            border: "none",
            borderRadius: 14,
            padding: "14px 12px",
            fontSize: 13,
            fontWeight: 600,
            color: "#374151",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 6,
            boxShadow: "0 1px 6px rgba(0,0,0,0.05)",
          }}
        >
          <Bell size={17} color="#F97316" />
          쉼터 상태 제보
        </button>
      </div>

      {/* Quick links */}
      <div style={{ margin: "14px 16px 0" }}>
        <div style={{ fontSize: 14, fontWeight: 600, color: "#374151", marginBottom: 10 }}>
          바로가기
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          {[
            { icon: "🗺", label: "주변 쉼터", tab: "map" as Tab },
            { icon: "⚙️", label: "맞춤 설정", tab: "my" as Tab },
            { icon: "⭐", label: "즐겨찾기", tab: "favorites" as Tab },
            { icon: "📢", label: "상태 제보", tab: "home" as Tab, detail: "report" },
          ].map((item) => (
            <button
              key={item.label}
              onClick={() => onNavigate(item.tab, item.detail)}
              style={{
                background: "#fff",
                border: "none",
                borderRadius: 14,
                padding: "14px 12px",
                display: "flex",
                alignItems: "center",
                gap: 8,
                cursor: "pointer",
                boxShadow: "0 1px 6px rgba(0,0,0,0.05)",
              }}
            >
              <span style={{ fontSize: 20 }}>{item.icon}</span>
              <span style={{ fontSize: 13, fontWeight: 500, color: "#374151" }}>
                {item.label}
              </span>
              <ChevronRight size={14} color="#9CA3AF" style={{ marginLeft: "auto" }} />
            </button>
          ))}
        </div>
      </div>

      {/* Nearby shelters preview */}
      <div style={{ margin: "14px 16px 0" }}>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: 10,
          }}
        >
          <div style={{ fontSize: 14, fontWeight: 600, color: "#374151" }}>
            주변 냉방쉼터
          </div>
          <button
            onClick={() => onNavigate("map")}
            style={{
              background: "none",
              border: "none",
              color: "#1D6FE8",
              fontSize: 13,
              fontWeight: 500,
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              gap: 2,
            }}
          >
            전체 보기 <ChevronRight size={14} />
          </button>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {nearbyShelters.map((s) => (
            <div
              key={s.name}
              style={{
                background: "#fff",
                borderRadius: 14,
                padding: "12px 14px",
                display: "flex",
                alignItems: "center",
                gap: 10,
                boxShadow: "0 1px 4px rgba(0,0,0,0.04)",
              }}
            >
              <div
                style={{
                  width: 40,
                  height: 40,
                  borderRadius: 12,
                  background: "#EFF4FF",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: 18,
                  flexShrink: 0,
                }}
              >
                {s.icon}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: "#111827" }}>
                  {s.name}
                </div>
                <div style={{ fontSize: 12, color: "#6B7280", marginTop: 2 }}>
                  {s.distance} · {s.walk}
                </div>
              </div>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 4 }}>
                <span
                  style={{
                    background: s.open ? "#ECFDF5" : "#FEF2F2",
                    color: s.open ? "#059669" : "#EF4444",
                    borderRadius: 20,
                    padding: "2px 8px",
                    fontSize: 11,
                    fontWeight: 600,
                  }}
                >
                  {s.open ? "운영 중" : "운영 종료"}
                </span>
                <span style={{ fontSize: 12, fontWeight: 600, color: "#1D6FE8" }}>
                  {s.score}점
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function StatusBadge({
  icon,
  label,
  color,
  bg,
}: {
  icon: React.ReactNode;
  label: string;
  color: string;
  bg: string;
}) {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 4,
        background: bg,
        color,
        borderRadius: 20,
        padding: "3px 9px",
        fontSize: 12,
        fontWeight: 500,
      }}
    >
      {icon}
      {label}
    </div>
  );
}

const nearbyShelters = [
  {
    icon: "🏢",
    name: "성북구청 민원실",
    distance: "380m",
    walk: "5분",
    open: true,
    score: 85,
  },
  {
    icon: "📚",
    name: "성북 어린이도서관",
    distance: "620m",
    walk: "8분",
    open: true,
    score: 78,
  },
  {
    icon: "🏪",
    name: "편의점 냉방쉼터 (GS25)",
    distance: "150m",
    walk: "2분",
    open: true,
    score: 61,
  },
];
