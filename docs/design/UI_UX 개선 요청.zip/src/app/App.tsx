import { useState } from "react";
import { BottomNav } from "./components/BottomNav";
import { HomeScreen } from "./components/HomeScreen";
import { MapScreen } from "./components/MapScreen";
import { AnalysisScreen } from "./components/AnalysisScreen";
import { ShelterDetailScreen } from "./components/ShelterDetailScreen";
import { SettingsScreen } from "./components/SettingsScreen";
import { ReportScreen } from "./components/ReportScreen";
import { FavoritesScreen } from "./components/FavoritesScreen";
import { MyScreen } from "./components/MyScreen";

type Tab = "home" | "map" | "analysis" | "favorites" | "my";
type Modal = "detail" | "report" | "settings" | null;

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>("home");
  const [modal, setModal] = useState<Modal>(null);

  const handleNavigate = (tab: Tab, detail?: string) => {
    if (detail === "detail") {
      setModal("detail");
    } else if (detail === "report") {
      setModal("report");
    } else {
      setActiveTab(tab);
      setModal(null);
    }
  };

  const handleMyNavigate = (screen: string) => {
    if (screen === "settings") setModal("settings");
    else if (screen === "favorites") setActiveTab("favorites");
  };

  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        minHeight: "100vh",
        background: "#1A1A2E",
        padding: "20px 0",
      }}
    >
      {/* Phone frame */}
      <div
        style={{
          width: 390,
          height: 844,
          background: "#F4F7FB",
          borderRadius: 50,
          overflow: "hidden",
          boxShadow: "0 30px 80px rgba(0,0,0,0.5), 0 0 0 10px #2A2A3E, 0 0 0 12px #1A1A2E",
          display: "flex",
          flexDirection: "column",
          position: "relative",
        }}
      >
        {/* Status bar notch */}
        <div
          style={{
            position: "absolute",
            top: 14,
            left: "50%",
            transform: "translateX(-50%)",
            width: 120,
            height: 34,
            background: "#000",
            borderRadius: 20,
            zIndex: 100,
          }}
        />

        {/* Screen content */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", position: "relative" }}>

          {/* Modal overlays */}
          {modal === "detail" && (
            <div style={{ position: "absolute", inset: 0, zIndex: 50, display: "flex", flexDirection: "column" }}>
              <ShelterDetailScreen onBack={() => setModal(null)} />
            </div>
          )}

          {modal === "report" && (
            <div style={{ position: "absolute", inset: 0, zIndex: 50, display: "flex", flexDirection: "column" }}>
              <ReportScreen onBack={() => setModal(null)} />
            </div>
          )}

          {modal === "settings" && (
            <div style={{ position: "absolute", inset: 0, zIndex: 50, display: "flex", flexDirection: "column" }}>
              <SettingsScreen />
            </div>
          )}

          {/* Main screens */}
          {!modal && (
            <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
              <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
                {activeTab === "home" && <HomeScreen onNavigate={handleNavigate} />}
                {activeTab === "map" && <MapScreen />}
                {activeTab === "analysis" && <AnalysisScreen />}
                {activeTab === "favorites" && <FavoritesScreen />}
                {activeTab === "my" && <MyScreen onNavigate={handleMyNavigate} />}
              </div>
              <BottomNav activeTab={activeTab} onTabChange={(tab) => { setActiveTab(tab); setModal(null); }} />
            </div>
          )}

          {/* Bottom nav even in modals (except report/settings which have back) */}
        </div>
      </div>
    </div>
  );
}
