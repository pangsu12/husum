
  # UI/UX 개선 요청

  This is a code bundle for UI/UX 개선 요청. The original project is available at https://www.figma.com/design/4GXya2qpX3bZL4ryvz7F3v/UI-UX-%EA%B0%9C%EC%84%A0-%EC%9A%94%EC%B2%AD.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  